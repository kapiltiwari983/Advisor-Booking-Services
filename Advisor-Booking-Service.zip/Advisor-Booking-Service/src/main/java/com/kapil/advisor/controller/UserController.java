package com.kapil.advisor.controller;




import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kapil.advisor.config.JwtUtil;
import com.kapil.advisor.model.Advisor;
import com.kapil.advisor.model.Appointment;
import com.kapil.advisor.request.UserLoginRequest;
import com.kapil.advisor.request.UserRequest;
import com.kapil.advisor.serviceimpl.AdvisorService;
import com.kapil.advisor.serviceimpl.AppointmentService;
import com.kapil.advisor.serviceimpl.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
	
	    @Autowired
	    private UserService userService;
	    
	    @Autowired
	    private AdvisorService advisorService;
	    
		/*
		 * @Autowired private BookingService bookingService;
		 */
	    
	    @Autowired
	    private AppointmentService appointmentService;

	    @PostMapping("/register")
	    public ResponseEntity<Map<String, String>> registerUser(@RequestBody UserRequest request) {
	    	
	        Long userId = userService.registerUser(request.getEmail(), request.getName(), request.getPassword());
	        String token = JwtUtil.generateToken(request.getPassword());
	        Map<String, String> response = new HashMap<>();
	        response.put("userId", String.valueOf(userId));
	        response.put("token", token);
	        return ResponseEntity.ok(response);
	    }
	    
	    @PostMapping("/login")
	    public ResponseEntity<Map<String, String>> loginUser(@RequestBody UserLoginRequest request) {
	        Map<String, String> response = userService.loginUser(request.getEmail(), request.getPassword());
	        return ResponseEntity.ok(response);
	    }
	    
	    @GetMapping
	    public List<Advisor> getAllAdvisors() {
	        return advisorService.getAllAdvisors();
	    }

	    @GetMapping("/{id}/advisor")
	    public ResponseEntity<Advisor> getAdvisorById(@PathVariable Long id) {
	        Advisor advisor = advisorService.getAdvisorById(id);
	        return ResponseEntity.ok(advisor);
	    }

	    @GetMapping("/{userId}")
	    public ResponseEntity<List<Appointment>> getAppointmentsByUserId(@PathVariable Long userId) {
	        List<Appointment> appointments = appointmentService.getAppointmentsByUserId(userId);
	        return ResponseEntity.ok(appointments);
	    }

	    @GetMapping("/advisor/{advisorId}")
	    public ResponseEntity<List<Appointment>> getAppointmentsByAdvisorId(@PathVariable Long advisorId) {
	        List<Appointment> appointments = appointmentService.getAppointmentsByAdvisorId(advisorId);
	        return ResponseEntity.ok(appointments);
	    }
    
	    @PostMapping("/{userId}/advisor/{advisorId}")
	    public ResponseEntity<String> bookAppointment(@RequestBody LocalDateTime bookingTime) {
	        appointmentService.bookAppointment(bookingTime);
	        return ResponseEntity.ok("Appointment booked successfully!");
	    }
	    
	    @GetMapping("/{userId}/advisor/booking")
	    public ResponseEntity<List<Map<String, Object>>> getAllBookedCallsByUserId(@PathVariable Long userId) {
	        List<Map<String, Object>> bookedCalls = appointmentService.getAllBookedCallsByUserId(userId);
	        return ResponseEntity.ok(bookedCalls);
	    }

		
}