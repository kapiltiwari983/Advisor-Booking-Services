package com.kapil.advisor.serviceimpl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.stereotype.Service;

import com.kapil.advisor.model.Advisor;
import com.kapil.advisor.model.Booking;
import com.kapil.advisor.model.User;
import com.kapil.advisor.repository.AdvisorRepository;
import com.kapil.advisor.repository.BookingRepository;
import com.kapil.advisor.repository.UserRepository;

@Service
public class BookingService {
    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AdvisorRepository advisorRepository;

    public Booking bookCall(Long userId, Long advisorId, LocalDateTime startTime, LocalDateTime endTime) throws NotFoundException {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new NotFoundException());

        Advisor advisor = advisorRepository.findById(advisorId)
                .orElseThrow(() -> new NotFoundException());

        Booking booking = new Booking();
        booking.setUser(user);
        booking.setAdvisor(advisor);
        booking.setStartTime(startTime);
        booking.setEndTime(endTime);

        return bookingRepository.save(booking);
    }

    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }
    public List<Booking> getBookingsByUserId(Long userId) throws NotFoundException {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new NotFoundException());

        return bookingRepository.findByUser(user);
    }
}
