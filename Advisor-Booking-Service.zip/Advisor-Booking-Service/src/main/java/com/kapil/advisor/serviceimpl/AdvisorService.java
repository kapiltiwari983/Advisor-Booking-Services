package com.kapil.advisor.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kapil.advisor.model.Advisor;
import com.kapil.advisor.repository.AdvisorRepository;

@Service
public class AdvisorService {

    @Autowired
    private AdvisorRepository advisorRepository;
    
    public void save(Advisor advisor) {
		advisorRepository.save(advisor);
	}

    public List<Advisor> getAllAdvisors() {
        return advisorRepository.findAll();
    }

    public Advisor getAdvisorById(Long advisorId) {
        return advisorRepository.findById(advisorId)
                .orElseThrow(() -> new RuntimeException("Advisor not found with id: " + advisorId));
    }
}