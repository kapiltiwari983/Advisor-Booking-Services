package com.kapil.advisor.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kapil.advisor.model.Appointment;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    List<Appointment> findByUserId(Long userId);
    List<Appointment> findByAdvisorId(Long advisorId);
    Appointment createAppointment(LocalDateTime bookingTime);
    
    
}