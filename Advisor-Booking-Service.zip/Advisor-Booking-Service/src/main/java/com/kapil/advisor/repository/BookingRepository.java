package com.kapil.advisor.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kapil.advisor.model.Booking;
import com.kapil.advisor.model.User;

public interface BookingRepository extends JpaRepository<Booking, Long> {
	
	 List<Booking> findByUser(User user);
}