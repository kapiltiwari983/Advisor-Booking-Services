package com.kapil.advisor.serviceimpl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.kapil.advisor.config.JwtUtil;
import com.kapil.advisor.model.User;
import com.kapil.advisor.repository.UserRepository;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public Long registerUser(String username, String password,String email ) {
        if (userRepository.findByUsername(username).isPresent()) {
            throw new RuntimeException("Username already exists");
        }

        User user = new User();
        user.setUserName(username);
        user.setEmail(email);
        user.setUserPwd(passwordEncoder.encode(password));

        User savedUser = userRepository.save(user);
        return savedUser.getId();
    }
    
    public Map<String, String> loginUser(String email, String password) {

        Long userId = userRepository.findByUsername(email)
                .orElseThrow(() -> new RuntimeException("User not found")).getId();

        String token = JwtUtil.generateToken(email);

        Map<String, String> response = new HashMap<>();
        response.put("email", String.valueOf(userId));
        response.put("token", token);

        return response;
    }
}