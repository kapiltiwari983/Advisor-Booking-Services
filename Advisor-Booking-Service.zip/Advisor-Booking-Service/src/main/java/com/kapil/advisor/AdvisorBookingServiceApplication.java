package com.kapil.advisor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdvisorBookingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdvisorBookingServiceApplication.class, args);
	}

}
