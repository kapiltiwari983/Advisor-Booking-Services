package com.kapil.advisor.response;

public class UserResponse {
	private Long userId;
	private String jwtToken;
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getJwtToken() {
		return jwtToken;
	}
	public void setJwtToken(String jwtToken) {
		this.jwtToken = jwtToken;
	}
	@Override
	public String toString() {
		return "UserResponse [userId=" + userId + ", jwtToken=" + jwtToken + "]";
	}
	

}
