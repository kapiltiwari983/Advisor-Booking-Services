package com.kapil.advisor.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

	@Entity
	public class Booking {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    @Column
	    @ManyToOne
	    private User user;
	    @Column
	    @ManyToOne
	    private Advisor advisor;
 
	    @Column
	    private LocalDateTime startTime;
	    @Column
	    private LocalDateTime endTime;
	    @Column
	    private String advisorName;
	    @Column
	    private String photoUrl;
	    
	    
	    
	    
		public void setPhotoUrl(String photoUrl) {
			this.photoUrl = photoUrl;
		}
		public void setAdvisorName(String advisorName) {
			this.advisorName = advisorName;
		}
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public User getUser() {
			return user;
		}
		public void setUser(User user) {
			this.user = user;
		}
		public Advisor getAdvisor() {
			return advisor;
		}
		public void setAdvisor(Advisor advisor) {
			this.advisor = advisor;
		}
		public LocalDateTime getStartTime() {
			return startTime;
		}
		public void setStartTime(LocalDateTime startTime) {
			this.startTime = startTime;
		}
		public LocalDateTime getEndTime() {
			return endTime;
		}
		public void setEndTime(LocalDateTime endTime) {
			this.endTime = endTime;
		}
		public String getAdvisorName() {
			return advisorName;
		}
		public LocalDateTime getBookingTime() {
			return startTime;
		}
		public String getPhotoUrl() {
			// TODO Auto-generated method stub
			return null;
		}
		
	}