package com.kapil.advisor.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kapil.advisor.model.Advisor;

public interface AdvisorRepository extends JpaRepository<Advisor, Long> {
	
    public Advisor save(Advisor advisor);
    public List<Advisor> findAll();
}
