package com.kapil.advisor.serviceimpl;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kapil.advisor.model.Appointment;
import com.kapil.advisor.repository.AppointmentRepository;

@Service
public class AppointmentService {
    @Autowired
    private AppointmentRepository appointmentRepository;

    public List<Appointment> getAppointmentsByUserId(Long userId) {
        return appointmentRepository.findByUserId(userId);
    }

    public List<Appointment> getAppointmentsByAdvisorId(Long advisorId) {
        return appointmentRepository.findByAdvisorId(advisorId);
    }
    
    public void bookAppointment(LocalDateTime bookingTime) {
        appointmentRepository.createAppointment(bookingTime);
    }
    
    public List<Map<String, Object>> getAllBookedCallsByUserId(Long userId) {
        List<Appointment> appointments = appointmentRepository.findByUserId(userId);

        return appointments.stream().map(appointment -> {
            Map<String, Object> result = new HashMap<>();
            result.put("bookingId", appointment.getId());
            result.put("advisorName", appointment.getAdvisorName());
            result.put("advisorId", appointment.getAdvisorId());
            result.put("profilePicUrl", appointment.getProfilePicUrl());
            result.put("bookingTime", appointment.getAppointmentTime());
            return result;
        }).collect(Collectors.toList());
    }

}