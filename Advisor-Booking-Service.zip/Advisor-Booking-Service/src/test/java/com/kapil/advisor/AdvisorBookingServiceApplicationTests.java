package com.kapil.advisor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvisorBookingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
