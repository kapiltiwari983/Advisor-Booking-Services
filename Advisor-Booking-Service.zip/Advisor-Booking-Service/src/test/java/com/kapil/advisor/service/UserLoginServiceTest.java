package com.kapil.advisor.service;

import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.kapil.advisor.repository.UserRepository;
import com.kapil.advisor.request.UserLoginRequest;
import com.kapil.advisor.serviceimpl.UserService;

import junit.framework.Assert;

@RunWith(MockitoJUnitRunner.class)
public class UserLoginServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    @Test
    public void testLoginUser_Success() {
        // Arrange
        String username = "john.doe";
        String password = "password123";
        UserLoginRequest mockUser = new UserLoginRequest(username, password);

        // Mock the behavior of userRepository.findByUsernameAndPassword
        //Mockito.when(userRepository.findByUsernameAndPassword(username, password)).thenReturn(mockUser);

        Mockito.when(userService.loginUser(username, password)).thenReturn((Map<String, String>) mockUser);
        // Act
        Map<String, String> loginResult = userService.loginUser(username, password);
        System.out.println("==="+loginResult);

       // Assert.assertTrue(loginResult);

        // Verify that userRepository.findByUsernameAndPassword was called with the correct arguments
        Mockito.verify(userRepository).findByUsername(username);
    }

	/*
	 * @Test public void testLoginUser_Failure() { // Arrange String username =
	 * "john.doe"; String password = "password123";
	 * 
	 * // Mock the behavior of userRepository.findByUsernameAndPassword
	 * Mockito.when(userRepository.findByUsernameAndPassword(username,
	 * password)).thenReturn(null);
	 * 
	 * // Act boolean loginResult = userLoginService.loginUser(username, password);
	 * 
	 * // Assert // Ensure the login is unsuccessful
	 * Assert.assertFalse(loginResult);
	 * 
	 * // Verify that userRepository.findByUsernameAndPassword was called with the
	 * correct arguments
	 * Mockito.verify(userRepository).findByUsernameAndPassword(username, password);
	 * }
	 */
}
